import wikipedia as wp
import urllib.request
import requests
import re
from bs4 import BeautifulSoup

from datetime import datetime
import tweepy
import pandas as pd
import boto3
import os
from io import BytesIO

# Set up S3 client
s3_client = boto3.client('s3')
bucket_name = 'xbot-proj'

# Set up Tweepy authentication using environment variables
API_KEY_B = os.environ['API_KEY_B']
API_KEY_SECRET_B = os.environ['API_KEY_SECRET_B']
ACCESS_TOKEN_B = os.environ['ACCESS_TOKEN_B']
ACCESS_TOKEN_SECRET_B = os.environ['ACCESS_TOKEN_SECRET_B']

auth = tweepy.OAuth1UserHandler(
    API_KEY_B, API_KEY_SECRET_B, ACCESS_TOKEN_B, ACCESS_TOKEN_SECRET_B
)
api = tweepy.API(auth)

client_v2 = tweepy.Client(
    consumer_key=API_KEY_B,
    consumer_secret=API_KEY_SECRET_B,
    access_token=ACCESS_TOKEN_B,
    access_token_secret=ACCESS_TOKEN_SECRET_B,
)


def scrape_births():
    # Base URL for the birthdays
    base_url = "https://www.onthisday.com/birthdays"

    # Get today's date
    today = datetime.now()
    month = today.strftime("%B").lower()  # Full month name in lowercase
    day = today.day

    # Construct the URL for today's birthdays
    url = f"{base_url}/{month}/{day}"

    # Send a request to the URL
    response = requests.get(url)
    if response.status_code == 200:
        # Parse the HTML content
        soup = BeautifulSoup(response.content, 'html.parser')

        # List to store the extracted data
        data = []

        # Find all birthday sections by class name
        birthday_sections = soup.find_all('div', class_='section section--highlight section--poi section--poi-b')

        # Process each birthday section
        for birthday_section in birthday_sections:
            # Extract the date (month and day)
            date_str = f"{month.capitalize()} {day}"

            # Extract the name and remove any date in brackets
            name_tag = birthday_section.find('span', class_='poi__heading-txt')
            if name_tag:
                name = name_tag.get_text(strip=True)
                # Remove date in brackets
                name = re.sub(r'\s*\(.*?\)', '', name).strip()
            else:
                name = 'Unknown'

            # Extract the year of birth and death
            date_tag = birthday_section.find('span', class_='poi__date')
            if date_tag:
                date_text = date_tag.get_text(strip=True).strip('()')
                if 'years old' in date_text:
                    birth_year = None
                    death_year = None
                    age = re.search(r'\d+', date_text)
                    age = age.group() if age else None
                    still_alive = True
                else:
                    age = None
                    years = date_text.split('-')
                    birth_year = years[0]
                    death_year = years[1] if len(years) > 1 else None
                    still_alive = False
            else:
                birth_year = None
                death_year = None
                age = None
                still_alive = False

            # Extract the description
            description_tag = birthday_section.find('p')
            if description_tag:
                # Remove the birth year tag from the description if present
                if still_alive:
                    birth_year_tags = description_tag.find_all('a', class_='birthDate')
                    for tag in birth_year_tags:
                        tag.decompose()  # Completely remove the tag and its content
                description = description_tag.get_text(separator=' ', strip=True)
                description = description.replace('"', '')  # Remove any double quotes
            else:
                description = 'No description found'

            # Append the extracted data (date, name, birth year, death year, age, description)
            data.append([date_str, name, birth_year, death_year, age, description, still_alive])

        # Create a DataFrame from the extracted data
        df = pd.DataFrame(data, columns=['Date', 'Name', 'Birth Year', 'Death Year', 'Age', 'Description', 'Still Alive'])

        # Set the index on 'Date'
        df.set_index(['Date'], inplace=True)

        print(f"Data extraction completed!")

        return df

    else:
        print(f"Failed to retrieve data. Status code: {response.status_code}")
        return None


def extract_wiki(query):
    try:
        print(f"Searching for: {query}")
        result = wp.search(query, results=1)
        print(f"Search results: {result}")

        if not result:
            print("No results found for query.")
            return None

        page = wp.page(result[0])
        page_html = page.html()
        soup = BeautifulSoup(page_html, 'html.parser')
        infobox = soup.find('table', {'class': 'infobox'})
        if infobox:
            image_tag = infobox.find('img')
            if image_tag:
                image_url = 'https:' + image_tag['src']
                print(f"Image URL: {image_url}")
                return image_url
        return None
    except Exception as e:
        print(f"Error fetching from Wikipedia: {e}")
        return None

def upload_to_s3(image_url, image_name):
    try:
        # Download image into memory
        image_data = urllib.request.urlopen(image_url).read()

        # Upload to S3
        s3_client.put_object(Bucket=bucket_name, Key=image_name, Body=image_data, ContentType='image/jpeg')
        print(f"Image {image_name} uploaded to S3 bucket {bucket_name}")
        return f"s3://{bucket_name}/{image_name}"
    except Exception as e:
        print(f"Error uploading image to S3: {e}")
        return None
        

def lambda_handler(event, context):
    print(f"Received event: {event}")
    df = scrape_births()
    df = df.drop_duplicates()

    if len(df) >= 50:
        df = df.sample(n=25, random_state=1)
        
    i = 0

    for index, row in df.iterrows():
        date = index[0]  # First part of the index (Date)
        year = index[1]  # Second part of the index (Year)
        month, day = date.split()
        
        # Access the Name and Event columns
        name = row['Name']
        event = row['Description']
        event = re.sub(r'\[.*?\]', '', event).strip()
        alive = row['Still Alive']
        birth_year = row["Birth Year"]
        age = row['Age']


        # Generate S3 image name
        image_name = f"{name.replace(' ', '_')}.jpg"

        # Fetch image from Wikipedia
        image_url = extract_wiki(name)
        if image_url:
            s3_image_url = upload_to_s3(image_url, image_name)
        else:
            s3_image_url = None
            
        # ['Date', 'Name', 'Birth Year', 'Death Year', 'Age', 'Description', 'Still Alive'])    
        try:
            if alive:
                if not birth_year and age:
                    current_year = datetime.now().year
                    birth_year = int(current_year) - int(age)
                tweet_text = f"{name.upper()}\n\n🎂 Born in {birth_year}, turns {age} today. \n\n{event}\n#FromToday #{day}{month.lower()}"
            else:
                death_year = row["Death Year"]
                tweet_text = f"{name.upper()}\n\n🎂 Born in {birth_year} and died in {death_year}.☠️ \n\n{event}\n#FromToday #{day}{month.lower()}"
        except Exception as e:
            print("Error: ",e)
            
        try:
            if s3_image_url:
                
                try:
                    response = s3_client.get_object(Bucket=bucket_name, Key=image_name)
                    image_data = response['Body'].read()  # Read the image data
                    print(f"Image {image_name} successfully retrieved from bucket {bucket_name}.")
                    
                    # Save the image data to a BytesIO object
                    image_file = BytesIO(image_data)
        
                    # Upload the image to Twitter using the BytesIO object
                    media = api.media_upload(filename=image_name, file=image_file)
                    client_v2.create_tweet(text=tweet_text, media_ids=[media.media_id])
        
                    # Delete the image from S3 after tweet posting
                    try:
                        s3_client.delete_object(Bucket=bucket_name, Key=image_name)
                        print(f"Image {image_name} successfully deleted from bucket {bucket_name}.")
                    except Exception as delete_error:
                        print(f"Error deleting image {image_name} from S3: {delete_error}")
        
                except Exception as e:
                    print(f"Error retrieving image {image_name} from S3: {e}")
                    raise
            else:
                # Post the tweet without an image
                client_v2.create_tweet(text=tweet_text)

            print(f"Successfully posted: {name}")
        except Exception as e:
            try:
                s3_client.delete_object(Bucket=bucket_name, Key=image_name)
                print(f"Image {image_name} successfully deleted from bucket {bucket_name}.")
            except Exception as delete_error:
                print(f"Error deleting image {image_name} from S3: {delete_error}")
            print(f"Error posting tweet: {e}")

        #if i == 2:
        #    break

        #i += 1