import wikipedia as wp
import urllib.request
import requests
from bs4 import BeautifulSoup

from datetime import datetime
import tweepy
import pandas as pd
import re
import boto3
import os
from io import BytesIO

# Set up S3 client
s3_client = boto3.client('s3')
bucket_name = 'xbot-proj'

# Set up Tweepy authentication using environment variables
API_KEY_D = os.environ['API_KEY_D']
API_KEY_SECRET_D = os.environ['API_KEY_SECRET_D']
ACCESS_TOKEN_D = os.environ['ACCESS_TOKEN_D']
ACCESS_TOKEN_SECRET_D = os.environ['ACCESS_TOKEN_SECRET_D']

auth = tweepy.OAuth1UserHandler(
    API_KEY_D, API_KEY_SECRET_D, ACCESS_TOKEN_D, ACCESS_TOKEN_SECRET_D
)
api = tweepy.API(auth)

client_v2 = tweepy.Client(
    consumer_key=API_KEY_D,
    consumer_secret=API_KEY_SECRET_D,
    access_token=ACCESS_TOKEN_D,
    access_token_secret=ACCESS_TOKEN_SECRET_D,
)

def scrape_deaths():
    # Base URL for the deaths
    base_url = "https://www.onthisday.com/deaths"

    # Get today's date
    today = datetime.now()
    month = today.strftime("%B").lower()
    day = today.day

    # Construct the URL for today's deaths
    url = f"{base_url}/{month}/{day}"

    # Send a request to the URL
    response = requests.get(url)
    
    # Check if the request was successful
    if response.status_code == 200:
        # Parse the HTML content
        soup = BeautifulSoup(response.content, 'html.parser')

        # List to store the extracted data
        data = []

        # Regular expressions to clean names and remove unwanted text
        name_re = re.compile(r'\[\d{4}(-\d{4})?\s*(BC|AD)?\]|\(\d{4}(-\d{4})?\s*(BC|AD)?\)|c\.\s*\d{4}-\d{4}\s*(BC|AD)?|c\.\s*\d{4}\s*(BC|AD)?')
        brackets_re = re.compile(r'\s*\(.*?\)\s*')

        # Find all death sections by class name
        death_sections = soup.find_all('div', class_='section section--highlight section--poi section--poi-b')

        # Process each death section
        for death_section in death_sections:
            # Extract the date (day and month)
            date_str = f"{day} {month.capitalize()}"
            
            # Extract the year
            year_tag = death_section.find('span', class_='poi__date')
            year = year_tag.get_text(strip=True).strip('()') if year_tag else 'Unknown'
            
            # Extract the name of the deceased
            name_tag = death_section.find('span', class_='poi__heading-txt')
            if name_tag:
                name = name_tag.get_text(strip=True)
                # Remove date and content inside brackets
                name = name_re.sub('', name).strip()
                # Remove additional brackets and their content
                name = brackets_re.sub('', name).strip()
            else:
                name = 'Unknown'
            
            # Extract the event description
            event_description = death_section.find('p')
            if event_description:
                # Remove any link and extra spaces
                for a_tag in event_description.find_all('a'):
                    a_tag.insert_before(' ')
                    a_tag.unwrap()
                event_text = event_description.get_text(separator=' ', strip=True)
            else:
                event_text = 'No death event found'
            
            # Remove double quotes from the event text
            event_text = event_text.replace('"', '')
            
            # Append the extracted data (date, year, name, event)
            data.append([date_str, year, name, event_text])

        # Create a DataFrame from the extracted data
        df = pd.DataFrame(data, columns=['Date', 'Year', 'Name', 'Event'])

        # Set a multi-level index on 'Date' and 'Year'
        df.set_index(['Date', 'Year'], inplace=True)

        print(f"Data extraction completed!")

        return df

    else:
        print(f"Failed to retrieve data. Status code: {response.status_code}")
        return None


def extract_wiki(query):
    try:
        print(f"Searching for: {query}")
        result = wp.search(query, results=1)
        print(f"Search results: {result}")

        if not result:
            print("No results found for query.")
            return None

        page = wp.page(result[0])
        page_html = page.html()
        soup = BeautifulSoup(page_html, 'html.parser')
        infobox = soup.find('table', {'class': 'infobox'})
        if infobox:
            image_tag = infobox.find('img')
            if image_tag:
                image_url = 'https:' + image_tag['src']
                print(f"Image URL: {image_url}")
                return image_url
        return None
    except Exception as e:
        print(f"Error fetching from Wikipedia: {e}")
        return None

def upload_to_s3(image_url, image_name):
    try:
        # Download image into memory
        image_data = urllib.request.urlopen(image_url).read()

        # Upload to S3
        s3_client.put_object(Bucket=bucket_name, Key=image_name, Body=image_data, ContentType='image/jpeg')
        print(f"Image {image_name} uploaded to S3 bucket {bucket_name}")
        return f"s3://{bucket_name}/{image_name}"
    except Exception as e:
        print(f"Error uploading image to S3: {e}")
        return None

def lambda_handler(event, context):
    df = scrape_deaths()

    if len(df) >= 50:
        df = df.sample(n=40, random_state=1)

    for index, row in df.iterrows():
        # Access the index (in this case, Date and Year)
        date = index[0]  # First part of the index (Date)
        year = index[1]  # Second part of the index (Year)
        day, month = date.split()
    
        # Access the Name and Event columns
        name = row['Name']
        event = row['Event']
        event = re.sub(r'\[.*?\]', '', event).strip()
        
        image_name = f"{name.replace(" ","_")}.jpg"
        
        image_url = extract_wiki(name)
        if image_url:
            s3_image_url = upload_to_s3(image_url, image_name)
        else:
            s3_image_url = None
        
        tweet_text = f"{name.upper()}\n\n📆{date}, {year}\n\n{event}\n#FromToday #{day}{month.lower()}"    

        try:
            if s3_image_url:

                
                response = s3_client.get_object(Bucket=bucket_name, Key=image_name)
                image_data = response['Body'].read()  # Read the image data
                print(f"Image {image_name} successfully retrieved from bucket {bucket_name}.")
                
                # Save the image data to a BytesIO object
                image_file = BytesIO(image_data)
    
                # Upload the image to Twitter using the BytesIO object
                media = api.media_upload(filename=image_name, file=image_file)
                client_v2.create_tweet(text=tweet_text, media_ids=[media.media_id])
    
                # Delete the image from S3 after tweet posting
                try:
                    s3_client.delete_object(Bucket=bucket_name, Key=image_name)
                    print(f"Image {image_name} successfully deleted from bucket {bucket_name}.")
                except Exception as delete_error:
                    print(f"Error deleting image {image_name} from S3: {delete_error}")
        
            else:
                # Post the tweet without an image
                client_v2.create_tweet(text=tweet_text)

            print(f"Successfully posted: {name}")
        except Exception as e:
            print(f"Error posting tweet: {e}")
            try:
                s3_client.delete_object(Bucket=bucket_name, Key=image_name)
                print(f"Image {image_name} successfully deleted from bucket {bucket_name}.")
            except Exception as delete_error:
                print(f"Error deleting image {image_name} from S3: {delete_error}")
            