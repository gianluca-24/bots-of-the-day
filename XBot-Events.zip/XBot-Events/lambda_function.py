import wikipedia as wp
import urllib.request
import requests
from bs4 import BeautifulSoup

from datetime import datetime
import tweepy
import pandas as pd
import boto3
import re
import os
from io import BytesIO

# Set up S3 client
s3_client = boto3.client('s3')
bucket_name = 'xbot-proj'

# Set up Tweepy authentication using environment variables
API_KEY_E = os.environ['API_KEY_E']
API_KEY_SECRET_E = os.environ['API_KEY_SECRET_E']
ACCESS_TOKEN_E = os.environ['ACCESS_TOKEN_E']
ACCESS_TOKEN_SECRET_E = os.environ['ACCESS_TOKEN_SECRET_E']

auth = tweepy.OAuth1UserHandler(
    API_KEY_E, API_KEY_SECRET_E, ACCESS_TOKEN_E, ACCESS_TOKEN_SECRET_E
)
api = tweepy.API(auth)

client_v2 = tweepy.Client(
    consumer_key=API_KEY_E,
    consumer_secret=API_KEY_SECRET_E,
    access_token=ACCESS_TOKEN_E,
    access_token_secret=ACCESS_TOKEN_SECRET_E,
)


def scrape_events():
    # Base URL for the events
    base_url = "https://www.onthisday.com/events"

    # Get today's date
    today = datetime.now()
    month = today.strftime("%B").lower()  # Full month name in lowercase
    day = today.day

    # Construct the URL for today's events
    url = f"{base_url}/{month}/{day}"

    # Send a request to the URL
    response = requests.get(url)
    if response.status_code == 200:
        # Parse the HTML content
        soup = BeautifulSoup(response.content, 'html.parser')

        # List to store the extracted data
        data = []

        # Define the list of icon sources to be excluded
        exclude_icons = [
            "/images/music-release.svg",
            "/images/baseball.svg",
            "/images/musician.svg",
            "/images/olympics.svg",
            "/images/sports-record-broken.svg",
            "/images/appears-on-tv-show.svg",
            "/images/music-concert.svg",
            "/images/american-football.svg",
            "/images/sport-defeat.svg",
            "/images/film-release-premier.svg"
        ]

        # Find all event sections by class name
        event_sections = soup.find_all('div', class_='section section--highlight section--poi')

        # Process each event section
        for event_section in event_sections:
            # Check if the event contains any of the excluded icons
            icon_tag = event_section.find('img', class_='section--icon')
            if icon_tag and icon_tag['src'] in exclude_icons:
                continue  # Skip this event if it has an excluded icon

            # Extract event title
            title_tag = event_section.find('span', class_='poi__heading-txt')
            title = title_tag.get_text(separator=' ', strip=True) if title_tag else 'No title found'
            title = title.replace('"', '')

            # Extract event year
            year_tag = event_section.find('a', class_='date')
            year = year_tag.get_text(strip=True) if year_tag else 'Unknown'

            # Extract event description
            event_description = event_section.find('p')
            if event_description:
                year_link = event_description.find('a', class_='date')
                if year_link:
                    year_link.decompose()
                event_text = event_description.get_text(separator=' ', strip=True)
            else:
                event_text = 'No event found'
            
            event_text = event_text.replace('"', '')

            # Extract event author
            author_tag = event_section.find('figcaption')
            author = author_tag.get_text(separator=' ', strip=True) if author_tag else 'No author found'

            # Append the extracted data (date, year, title, event, author)
            data.append([f"{day} {month.capitalize()}", year, title, event_text, author])

        # Create a DataFrame from the extracted data
        df = pd.DataFrame(data, columns=['Date', 'Year', 'Title', 'Event', 'Author'])
        df.set_index(['Date', 'Year'], inplace=True)
        print("Data extraction completed!")
        return df
    else:
        print(f"Failed to retrieve data. Status code: {response.status_code}")
        return pd.DataFrame()

def extract_wiki(query):
    try:
        print(f"Searching for: {query}")
        result = wp.search(query, results=1)
        print(f"Search results: {result}")

        if not result:
            print("No results found for query.")
            return None

        page = wp.page(result[0])
        page_html = page.html()
        soup = BeautifulSoup(page_html, 'html.parser')
        infobox = soup.find('table', {'class': 'infobox'})
        if infobox:
            image_tag = infobox.find('img')
            if image_tag:
                image_url = 'https:' + image_tag['src']
                print(f"Image URL: {image_url}")
                return image_url
        return None
    except Exception as e:
        print(f"Error fetching from Wikipedia: {e}")
        return None

def upload_to_s3(image_url, image_name):
    try:
        # Download image into memory
        image_data = urllib.request.urlopen(image_url).read()

        # Upload to S3
        s3_client.put_object(Bucket=bucket_name, Key=image_name, Body=image_data, ContentType='image/jpeg')
        print(f"Image {image_name} uploaded to S3 bucket {bucket_name}")
        return f"s3://{bucket_name}/{image_name}"
    except Exception as e:
        print(f"Error uploading image to S3: {e}")
        return None

def lambda_handler(event, context):
    df = scrape_events()

    if len(df) >= 50:
        df = df.sample(n=25, random_state=1)
        
    i = 0

    for index, row in df.iterrows():
        date = index[0]
        day, month = date.split()
        year = index[1]
        title = row['Title']
        event_text = row['Event']
        event_text = re.sub(r'\[.*?\]', '', event_text).strip()

        if title.upper() in ["LAVER CUP MEN'S TENNIS","TOUR CHAMPIONSHIP","AMERICA'S CUP","NFL",
                             "TEAM MANAGER", "MUSIC HISTORY", "CONTRACT OF INTEREST", "EVENT OF INTEREST", 
                             "SPORTS HISTORY", "BASEBALL HISTORY", "BASEBALL RECORD","US WIN BASKETBALL GOLD"]:
            continue

        # Generate S3 image name
        image_name = f"{title.replace(' ', '_')}.jpg"

        # Fetch image from Wikipedia
        image_url = extract_wiki(title)
        if image_url:
            s3_image_url = upload_to_s3(image_url, image_name)
        else:
            s3_image_url = None

        tweet_text = f"{title.upper()}\n\n📆{date}, {year}\n\n{event_text}\n#FromToday #{day}{month.lower()}"

        try:
            if s3_image_url:

                try:
                    response = s3_client.get_object(Bucket=bucket_name, Key=image_name)
                    image_data = response['Body'].read()  # Read the image data
                    print(f"Image {image_name} successfully retrieved from bucket {bucket_name}.")
                    
                    # Save the image data to a BytesIO object
                    image_file = BytesIO(image_data)
        
                    # Upload the image to Twitter using the BytesIO object
                    media = api.media_upload(filename=image_name, file=image_file)
                    client_v2.create_tweet(text=tweet_text, media_ids=[media.media_id])
        
                    # Delete the image from S3 after tweet posting
                    try:
                        s3_client.delete_object(Bucket=bucket_name, Key=image_name)
                        print(f"Image {image_name} successfully deleted from bucket {bucket_name}.")
                    except Exception as delete_error:
                        print(f"Error deleting image {image_name} from S3: {delete_error}")
        
                except Exception as e:
                    print(f"Error retrieving image {image_name} from S3: {e}")
                    raise

            else:
                # Post the tweet without an image
                client_v2.create_tweet(text=tweet_text)

            print(f"Successfully posted: {title}")
        except Exception as e:
            try:
                s3_client.delete_object(Bucket=bucket_name, Key=image_name)
                print(f"Image {image_name} successfully deleted from bucket {bucket_name}.")
            except Exception as delete_error:
                print(f"Error deleting image {image_name} from S3: {delete_error}")
            print(f"Error posting tweet: {e}")
        
        #if i == 2:
        #    break
        #i += 1


